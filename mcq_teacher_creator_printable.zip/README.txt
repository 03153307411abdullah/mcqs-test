FEATURES
- Create test
- Add unlimited MCQs
- Set correct answers
- Set passing percentage (default 50%)
- Publish student link
- Student results saved in browser
- Separate PASS and FAIL sheets
- Print Pass Sheet
- Print Fail Sheet
- Print All Results

NOTE:
This version stores results in browser localStorage. For results from students on different devices to appear automatically on the teacher's device, an online backend/database is required.
